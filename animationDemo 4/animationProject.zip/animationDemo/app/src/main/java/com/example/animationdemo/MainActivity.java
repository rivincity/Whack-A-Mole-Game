package com.example.animationdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;

import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;

public class MainActivity extends AppCompatActivity {
    ConstraintLayout layout;
    TextView textView;
    ImageView imageView;
    boolean timer = true;
    static int seconds = 60;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.id_timer);
        layout = findViewById(R.id.id_layout);
        imageView = findViewById(R.id.id_vold5);
        layout = new ConstraintLayout(this);

        Timer thread = new Timer();
        thread.start();

        ScaleAnimation scaleAnimation = new ScaleAnimation(1.0f, 0.1f, 1.0f, 0.1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        scaleAnimation.setDuration(100);
        scaleAnimation.setFillAfter(true);
        imageView.startAnimation(scaleAnimation);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ScaleAnimation scaleAnimation2 = new ScaleAnimation(0.1f, 1.0f, 0.1f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                scaleAnimation2.setDuration(2000);
                imageView.startAnimation(scaleAnimation2);
            }
        }, 1000);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageView.setEnabled(false);
                ScaleAnimation scaleAnimation3 = new ScaleAnimation(0.2f, 0.1f, 0.2f, 0.1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                scaleAnimation3.setDuration(50);
                scaleAnimation3.setFillAfter(true);
                imageView.startAnimation(scaleAnimation3);
                /*ImageView i = new ImageView(MainActivity.this);
                i.setImageResource(R.drawable.voldemort);
                i.setContentDescription(getResources().getString(R.string.));
                i.setAdjustViewBounds(true);
                i.setLayoutParams(new ViewGroup);
                layout.addView(i);
                setContentView(layout);*/
            }
        });
        /*ScaleAnimation scaleAnimation4 = new ScaleAnimation(1.0f, 0.1f, 1.0f, 0.1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                scaleAnimation4.setDuration(1000);
                scaleAnimation4.setFillAfter(true);
                imageView.startAnimation(scaleAnimation4);*/
    }
    public class Timer extends Thread
    {
        @Override
        public void run() {
                while(timer)
                {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    seconds--;
                    MainActivity.this.runOnUiThread(new Runnable() {
                        public void run() {
                            textView.setText(String.valueOf(seconds));
                        }
                    });
                    if(seconds == 0)
                    {
                        timer = false;
                    }
                }
            }
    }

}
